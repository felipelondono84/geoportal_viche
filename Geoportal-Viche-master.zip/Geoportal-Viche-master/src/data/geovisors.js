export const geovisorNodes = [
  {
    id: 1,
    name: "Alto y medio Baudó",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed nulla et eros mattis elementum. Sed et nibh odio.",
    isActive: true,
    geovisorLink: "#",
    moreInfoLink: "#"
  },
  {
    id: 2,
    name: "Litoral Chocoano",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed nulla et eros mattis elementum. Sed et nibh odio.",
    isActive: false,
    geovisorLink: "#",
    moreInfoLink: "#"
  },
  {
    id: 3,
    name: "Bajo Baudó",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed nulla et eros mattis elementum. Sed et nibh odio.",
    isActive: false,
    geovisorLink: "#",
    moreInfoLink: "#"
  },
  {
    id: 4,
    name: "Río Atrato",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed nulla et eros mattis elementum. Sed et nibh odio.",
    isActive: false,
    geovisorLink: "#",
    moreInfoLink: "#"
  },
  {
    id: 5,
    name: "Río San Juan",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed nulla et eros mattis elementum. Sed et nibh odio.",
    isActive: false,
    geovisorLink: "#",
    moreInfoLink: "#"
  },
  {
    id: 6,
    name: "Valle del Cauca",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed nulla et eros mattis elementum. Sed et nibh odio.",
    isActive: false,
    geovisorLink: "#",
    moreInfoLink: "#"
  },
  {
    id: 7,
    name: "Cauca",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed nulla et eros mattis elementum. Sed et nibh odio.",
    isActive: false,
    geovisorLink: "#",
    moreInfoLink: "#"
  },
  {
    id: 8,
    name: "Nariño",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed nulla et eros mattis elementum. Sed et nibh odio.",
    isActive: false,
    geovisorLink: "#",
    moreInfoLink: "#"
  }
];