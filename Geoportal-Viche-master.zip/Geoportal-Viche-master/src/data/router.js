export const links = [
  {
    title: "Inicio",
    href: "#",
  },
  {
    title: "Geovisor",
    href: "#",
  },
  {
    title: "Nodos",
    href: "#",
  },
  {
    title: "¿Quiénes Somos?",
    href: "#",
  },
  {
    title: "Aliados",
    href: "#",
  },
];